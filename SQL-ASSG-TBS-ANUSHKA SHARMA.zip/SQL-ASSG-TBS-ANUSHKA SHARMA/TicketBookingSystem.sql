-- Task 1: Database Design
CREATE DATABASE TicketBookingSystem;

USE TicketBookingSystem;

-- Venu Table
CREATE TABLE Venu (
    venue_id INT AUTO_INCREMENT PRIMARY KEY,
    venue_name VARCHAR(255) NOT NULL,
    address VARCHAR(255) NOT NULL
);

-- Event Table
CREATE TABLE Event (
    event_id INT AUTO_INCREMENT PRIMARY KEY,
    event_name VARCHAR(255) NOT NULL,
    event_date DATE NOT NULL,
    event_time TIME NOT NULL,
    venue_id INT,
    total_seats INT NOT NULL,
    available_seats INT NOT NULL,
    ticket_price DECIMAL(10, 2) NOT NULL,
    event_type ENUM('Movie', 'Sports', 'Concert') NOT NULL,
    booking_id INT
);


-- Customer Table
CREATE TABLE Booking (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    event_id INT,
    num_tickets INT NOT NULL,
    total_cost DECIMAL(10, 2) NOT NULL,
    booking_date DATE NOT NULL
);

-- Booking Table
CREATE TABLE Customer (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone_number VARCHAR(15) NOT NULL,
    booking_id INT
);

-- Alter tables to add foreign key constraints.
ALTER TABLE Event
ADD FOREIGN KEY (venue_id) REFERENCES Venu(venue_id) ON DELETE CASCADE,
ADD FOREIGN KEY (booking_id) REFERENCES Booking(booking_id) ON DELETE SET NULL;

ALTER TABLE Booking
ADD FOREIGN KEY (customer_id) REFERENCES Customer(customer_id) ON DELETE CASCADE,
ADD FOREIGN KEY (event_id) REFERENCES Event(event_id) ON DELETE CASCADE;

ALTER TABLE Customer
ADD FOREIGN KEY (booking_id) REFERENCES Booking(booking_id) ON DELETE SET NULL;



