USE TicketBookingSystem;
-- Tasks 2: Select, Where, Between, AND, LIKE:
-- 1. Write a SQL query to insert at least 10 sample records into each table.
INSERT INTO Venu (venue_name, address) VALUES
    ('Venue 1', 'Address 1'),
    ('Venue 2', 'Address 2'),
    ('Venue 3', 'Address 3'),
    ('Venue 4', 'Address 4'),
    ('Venue 5', 'Address 5'),
    ('Venue 6', 'Address 6'),
    ('Venue 7', 'Address 7'),
    ('Venue 8', 'Address 8'),
    ('Venue 9', 'Address 9'),
    ('Venue 10', 'Address 10');
SELECT* FROM VENU;

INSERT INTO Event (event_name, event_date, event_time, venue_id, total_seats, available_seats, ticket_price, event_type, booking_id) VALUES
    ('Event 1', '2023-01-01', '18:00:00', 1, 200, 200, 25.00, 'Concert', 1),
    ('Event 2', '2023-02-15', '20:30:00', 2, 150, 150, 30.00, 'Movie', 2),
    ('Event 3', '2023-03-10', '15:45:00', 3, 100, 100, 20.00, 'Sports', 3),
    ('Event 4', '2023-04-05', '19:00:00', 4, 300, 300, 15.00, 'Concert', 4),
    ('Event 5', '2023-05-20', '21:15:00', 5, 250, 250, 35.00, 'Movie', 5),
    ('Event 6', '2023-06-12', '17:30:00', 6, 180, 180, 22.50, 'Sports', 6),
    ('Event 7', '2023-07-25', '22:00:00', 7, 120, 120, 18.00, 'Concert', 7),
    ('Event 8', '2023-08-08', '16:45:00', 8, 220, 220, 28.00, 'Movie', 8),
    ('Event 9', '2023-09-18', '19:30:00', 9, 170, 170, 32.50, 'Sports', 9),
    ('Event 10', '2023-10-30', '14:00:00', 10, 190, 190, 21.00, 'Concert', 10);
    
INSERT INTO Customer (customer_name, email, phone_number) VALUES
    ('John Doe', 'john.doe@email.com', '123-456-7890'),
    ('Jane Smith', 'jane.smith@email.com', '987-654-3210'),
    ('Robert Johnson', 'robert.johnson@email.com', '555-123-4567'),
    ('Emily Davis', 'emily.davis@email.com', '111-222-3333'),
    ('Michael White', 'michael.white@email.com', '999-888-7777'),
    ('Sarah Brown', 'sarah.brown@email.com', '444-555-6666'),
    ('Daniel Miller', 'daniel.miller@email.com', '777-666-5555'),
    ('Olivia Wilson', 'olivia.wilson@email.com', '222-333-4444'),
    ('James Lee', 'james.lee@email.com', '666-777-8888'),
    ('Sophia Taylor', 'sophia.taylor@email.com', '333-444-5555');
    
INSERT INTO Booking (customer_id, event_id, num_tickets, total_cost, booking_date) VALUES
    (1, 1, 2, 50.00, '2023-01-01'),
    (2, 3, 1, 20.00, '2023-03-10'),
    (3, 5, 4, 140.00, '2023-05-20'),
    (4, 7, 3, 54.00, '2023-07-25'),
    (5, 9, 2, 65.00, '2023-09-18'),
    (6, 2, 5, 150.00, '2023-02-15'),
    (7, 4, 1, 15.00, '2023-04-05'),
    (8, 6, 3, 67.50, '2023-06-12'),
    (9, 8, 2, 56.00, '2023-08-08'),
    (10, 10, 4, 84.00, '2023-10-30');
SELECT * FROM BOOKING;

-- 2. Write a SQL query to list all Events.
SELECT * FROM Event;

-- 3. Write a SQL query to select events with available tickets.
SELECT * FROM Event WHERE available_seats > 0;

-- 4. Write a SQL query to select events name partial match with ‘cup’.
INSERT INTO Event (event_name, event_date, event_time, venue_id, total_seats, available_seats, ticket_price, event_type, booking_id) VALUES
    ('Little Cupcakes', '2023-12-16', '18:00:00', 1, 200, 200, 1111.00, 'Concert',NULL);
SELECT * FROM Event WHERE event_name LIKE '%cup%';

-- 5. Write a SQL query to select events with ticket price range is between 1000 to 2500.
SELECT * FROM Event WHERE ticket_price BETWEEN 1000 AND 2500;

-- 6. Write a SQL query to retrieve events with dates falling within a specific range.
SELECT * FROM Event WHERE event_date BETWEEN '2023-12-15' AND '2023-12-20';

-- 7. Write a SQL query to retrieve events with available tickets that also have "Concert" in their name.
INSERT INTO Event (event_name, event_date, event_time, venue_id, total_seats, available_seats, ticket_price, event_type, booking_id) VALUES
    ('TaylorSwift Concert', '2023-12-16', '18:00:00', 1, 200, 200, 1111.00, 'Concert',NULL);
INSERT INTO Event (event_name, event_date, event_time, venue_id, total_seats, available_seats, ticket_price, event_type, booking_id) VALUES
    ('HarryStyles Concert', '2023-12-16', '18:00:00', 1, 200, 0, 1111.00, 'Concert',NULL);
SELECT * FROM Event WHERE available_seats > 0 AND event_name LIKE '%Concert%';

-- 8. Write a SQL query to retrieve users in batches of 5, starting from the 6th user.
SELECT * FROM Customer LIMIT 5 OFFSET 5;

-- 9. Write a SQL query to retrieve bookings details contains booked no of ticket more than 4.
SELECT * FROM Booking WHERE num_tickets > 4;

-- 10. Write a SQL query to retrieve customer information whose phone number end with ‘000’
SELECT * FROM Customer WHERE phone_number LIKE '%000';

-- 11. Write a SQL query to retrieve the events in order whose seat capacity more than 15000.
SELECT * FROM Event WHERE total_seats > 15000 ORDER BY total_seats;

-- 12. Write a SQL query to select events name not start with ‘x’, ‘y’, ‘z
SELECT * FROM Event WHERE NOT (event_name LIKE 'x%' OR event_name LIKE 'y%' OR event_name LIKE 'z%');


-- Tasks 3: Aggregate functions, Having, Order By, GroupBy and Joins:
-- 1. Write a SQL query to List Events and Their Average Ticket Prices.
SELECT event_id, event_name, AVG(ticket_price) AS average_ticket_price
FROM Event
GROUP BY event_id, event_name;

-- 2. Write a SQL query to Calculate the Total Revenue Generated by Events.
SELECT SUM(total_cost) AS total_revenue
FROM Booking;

-- 3. Write a SQL query to find the event with the highest ticket sales.
SELECT Event.event_id, Event.event_name, SUM(Booking.num_tickets) AS total_tickets_sold
FROM Booking
JOIN Event ON Booking.event_id = Event.event_id
GROUP BY Event.event_id, Event.event_name
ORDER BY total_tickets_sold DESC
LIMIT 1;

-- 4. Write a SQL query to Calculate the Total Number of Tickets Sold for Each Event.
SELECT Event.event_id, Event.event_name, SUM(Booking.num_tickets) AS total_tickets_sold
FROM Booking
JOIN Event ON Booking.event_id = Event.event_id
GROUP BY Event.event_id, Event.event_name
LIMIT 0, 1000;

-- 5. Write a SQL query to Find Events with No Ticket Sales.
SELECT Event.event_id, Event.event_name
FROM Event
LEFT JOIN Booking ON Event.event_id = Booking.event_id
WHERE Booking.booking_id IS NULL;

-- 6. Write a SQL query to Find the User Who Has Booked the Most Tickets.
SELECT customer_id, COUNT(*) AS total_tickets_booked
FROM Booking
GROUP BY customer_id
ORDER BY total_tickets_booked DESC
LIMIT 1;

-- 7. Write a SQL query to List Events and the total number of tickets sold for each month.
SELECT DATE_FORMAT(Booking.booking_date, '%Y-%m') AS month, Event.event_id, Event.event_name, SUM(Booking.num_tickets) AS total_tickets_sold
FROM Booking
JOIN Event ON Booking.event_id = Event.event_id
GROUP BY month, Event.event_id, Event.event_name
LIMIT 0, 1000;

-- 8. Write a SQL query to calculate the average Ticket Price for Events in Each Venue.
SELECT Venu.venue_id, Venu.venue_name, AVG(Event.ticket_price) AS average_ticket_price
FROM Event
JOIN Venu ON Event.venue_id = Venu.venue_id
GROUP BY Venu.venue_id, Venu.venue_name;

-- 9. Write a SQL query to calculate the total Number of Tickets Sold for Each Event Type.
SELECT event_type, SUM(num_tickets) AS total_tickets_sold
FROM Event
JOIN Booking ON Event.event_id = Booking.event_id
GROUP BY event_type;

-- 10. Write a SQL query to calculate the total Revenue Generated by Events in Each Year.
SELECT YEAR(booking_date) AS year, SUM(total_cost) AS total_revenue
FROM Booking
GROUP BY year;

-- 11. Write a SQL query to list users who have booked tickets for multiple events.
SELECT customer_id, COUNT(DISTINCT event_id) AS events_booked
FROM Booking
GROUP BY customer_id
HAVING events_booked > 1;

-- 12. Write a SQL query to calculate the Total Revenue Generated by Events for Each User.
SELECT customer_id, SUM(total_cost) AS total_revenue
FROM Booking
GROUP BY customer_id;

-- 13. Write a SQL query to calculate the Average Ticket Price for Events in Each Category and Venue.
SELECT Venu.venue_id, Venu.venue_name, event_type, AVG(Event.ticket_price) AS average_ticket_price
FROM Event
JOIN Venu ON Event.venue_id = Venu.venue_id
GROUP BY Venu.venue_id, Venu.venue_name, event_type;

-- 14. Write a SQL query to list Users and the Total Number of Tickets They've Purchased in the Last 30 Days
SELECT customer_id, COUNT(*) AS total_tickets_purchased
FROM Booking
WHERE booking_date >= CURDATE() - INTERVAL 30 DAY
GROUP BY customer_id;

-- Tasks 4: Subquery and its types
-- 1. Calculate the Average Ticket Price for Events in Each Venue Using a Subquery.
SELECT venue_id, venue_name,
       (SELECT AVG(ticket_price) FROM Event WHERE Event.venue_id = Venu.venue_id) AS average_ticket_price
FROM Venu;

-- 2. Find Events with More Than 50% of Tickets Sold using subquery.
SELECT event_id, event_name
FROM Event
WHERE (SELECT SUM(num_tickets) FROM Booking WHERE Booking.event_id = Event.event_id) > (total_seats * 0.5);

-- 3. Calculate the Total Number of Tickets Sold for Each Event.
SELECT event_id, event_name,
       (SELECT SUM(num_tickets) FROM Booking WHERE Booking.event_id = Event.event_id) AS total_tickets_sold
FROM Event;

-- 4. Find Users Who Have Not Booked Any Tickets Using a NOT EXISTS Subquery.
SELECT customer_id, customer_name
FROM Customer
WHERE NOT EXISTS (SELECT 1 FROM Booking WHERE Booking.customer_id = Customer.customer_id);


-- 5. List Events with No Ticket Sales Using a NOT IN Subquery.
SELECT event_id, event_name
FROM Event
WHERE event_id NOT IN (SELECT DISTINCT event_id FROM Booking);


-- 6. Calculate the Total Number of Tickets Sold for Each Event Type Using a Subquery in the FROM Clause.
SELECT event_type, SUM(total_tickets_sold) AS total_tickets_sold
FROM (
    SELECT event_id, event_type, 
           (SELECT SUM(num_tickets) FROM Booking WHERE Booking.event_id = Event.event_id) AS total_tickets_sold
    FROM Event
) AS Subquery
GROUP BY event_type;

-- 7. Find Events with Ticket Prices Higher Than the Average Ticket Price Using a Subquery in the WHERE Clause.
SELECT event_id, event_name, ticket_price
FROM Event
WHERE ticket_price > (SELECT AVG(ticket_price) FROM Event);

-- 8. Calculate the Total Revenue Generated by Events for Each User Using a Correlated Subquery.
SELECT customer_id, customer_name,
       (SELECT SUM(total_cost) FROM Booking WHERE Booking.customer_id = Customer.customer_id) AS total_revenue
FROM Customer;

-- 9. List Users Who Have Booked Tickets for Events in a Given Venue Using a Subquery in the WHERE Clause.
SELECT customer_id, customer_name
FROM Customer
WHERE EXISTS (SELECT 1 FROM Booking JOIN Event ON Booking.event_id = Event.event_id WHERE Event.venue_id = 'your_venue_id' AND Booking.customer_id = Customer.customer_id);

-- 10. Calculate the Total Number of Tickets Sold for Each Event Category Using a Subquery with GROUP BY.
SELECT event_type, SUM(total_tickets_sold) AS total_tickets_sold
FROM (
    SELECT event_type, 
           (SELECT SUM(num_tickets) FROM Booking WHERE Booking.event_id = Event.event_id) AS total_tickets_sold
    FROM Event
) AS Subquery
GROUP BY event_type;

-- 11. Find Users Who Have Booked Tickets for Events in each Month Using a Subquery with DATE_FORMAT.
SELECT customer_id, customer_name, booking_month
FROM (
    SELECT Customer.customer_id, customer_name, DATE_FORMAT(booking_date, '%Y-%m') AS booking_month
    FROM Customer
    JOIN Booking ON Customer.customer_id = Booking.customer_id
) AS Subquery
GROUP BY customer_id, booking_month;

-- 12. Calculate the Average Ticket Price for Events in Each Venue Using a Subquery.
SELECT venue_id, venue_name,
       (SELECT AVG(ticket_price) FROM Event WHERE Event.venue_id = Venu.venue_id) AS average_ticket_price
FROM Venu;
