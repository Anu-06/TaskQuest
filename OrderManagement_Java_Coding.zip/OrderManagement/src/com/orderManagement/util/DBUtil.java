package com.orderManagement.util;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtil {
    private static Connection connStudent;

    public static Connection createConnection() throws ClassNotFoundException, SQLException {
        System.out.println("Resource Bundle Name: mySql");

        // Load properties directly using Properties class
        Properties properties = new Properties();
        try (InputStream input = DBUtil.class.getClassLoader().getResourceAsStream("mySql.properties")) {
            if (input == null) {
                System.out.println("Unable to find mySql.properties file.");
                throw new IOException("Unable to find mySql.properties file.");
            }
            properties.load(input);
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Error loading mySql.properties file.", e);
        }

        // Print properties file path
        String filePath = DBUtil.class.getClassLoader().getResource("mySql.properties").getPath();
        System.out.println("Properties file path: " + filePath);

        // Use the properties to get the required values
        String url = properties.getProperty("url");
        String username = properties.getProperty("username");
        String password = properties.getProperty("password");
        String driver = properties.getProperty("driver");

        Class.forName(driver);

        connStudent = DriverManager.getConnection(url, username, password);
        System.out.println("Connection established.");
        return connStudent;
    }

    public static void closeConnection() throws SQLException {
        connStudent.close();
    }
}
