package com.orderManagement.main;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;
import com.orderManagement.Dao.IOrderManagementRepository;
import com.orderManagement.Dao.OrderManagementRepositoryImpl;
import com.orderManagement.entity.Product;
import com.orderManagement.entity.User;
import com.orderManagement.exception.OrderNotFoundException;
import com.orderManagement.exception.UserNotFoundException;
import com.orderManagement.util.DBUtil;

public class MainModule {
    public static void main(String[] args) {
    	try {
        	IOrderManagementRepository orderManagementRepository = new OrderManagementRepositoryImpl(DBUtil.createConnection());

    		
        
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Menu:");
            System.out.println("1. Create User");
            System.out.println("2. Create Product");
            System.out.println("3. Cancel Order");
            System.out.println("4. Get All Products");
            System.out.println("5. Get Order by User");
            System.out.println("6. Exit");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    // Create User
                    System.out.print("Enter user ID: ");
                    int userId = scanner.nextInt();
                    scanner.nextLine(); 

                    System.out.print("Enter username: ");
                    String username = scanner.nextLine();

                    System.out.print("Enter password: ");
                    String password = scanner.nextLine();

                    System.out.print("Enter role (Admin/User): ");
                    String role = scanner.nextLine();

                    User user = new User(userId, username, password, role);
                    orderManagementRepository.createUser(user);
                    System.out.println("User created successfully.");
                    break;

                case 2:
                    // Create Product
                    System.out.print("Enter admin user ID: ");
                    int adminUserId = scanner.nextInt();
                    scanner.nextLine(); 

                    System.out.print("Enter product ID: ");
                    int productId = scanner.nextInt();
                    scanner.nextLine();
                    
                    System.out.print("Enter product name: ");
                    String productName = scanner.nextLine();

                    System.out.print("Enter description: ");
                    String description = scanner.nextLine();

                    System.out.print("Enter price: ");
                    double price = scanner.nextDouble();
                    scanner.nextLine(); 

                    System.out.print("Enter quantity in stock: ");
                    int quantityInStock = scanner.nextInt();
                    scanner.nextLine(); 

                    System.out.print("Enter type (Electronics/Clothing): ");
                    String type = scanner.nextLine();

                    Product product = new Product(productId, productName, description, price, quantityInStock, type);
                    User adminUser = new User(adminUserId, "", "", "Admin");

                    try {
                        orderManagementRepository.createProduct(adminUser, product);
                        System.out.println("Product created successfully.");
                    } catch (UserNotFoundException e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 3:
                    // Cancel Order
                    System.out.print("Enter user ID: ");
                    int userIdCancel = scanner.nextInt();
                    scanner.nextLine(); 

                    System.out.print("Enter order ID: ");
                    int orderIdCancel = scanner.nextInt();
                    scanner.nextLine(); 

                    try {
                        orderManagementRepository.cancelOrder(userIdCancel, orderIdCancel);
                        System.out.println("Order canceled successfully.");
                    } catch (UserNotFoundException | OrderNotFoundException e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 4:
                    // Get All Products
                    List<Product> products = orderManagementRepository.getAllProducts();
                    System.out.println("All Products:");
                    for (Product p : products) {
                        System.out.println(p);
                    }
                    break;

                case 5:
                    // Get Order by User
                    System.out.print("Enter user ID: ");
                    int userIdOrder = scanner.nextInt();
                    scanner.nextLine(); 

                    try {
                        List<Product> orderedProducts = orderManagementRepository.getOrderByUser(new User(userIdOrder, "", "", ""));
                        System.out.println("Products Ordered by User:");
                        for (Product p : orderedProducts) {
                            System.out.println(p);
                        }
                    } catch (UserNotFoundException e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 6:
                    System.out.println("Exiting the system. Goodbye!");
                    scanner.close();
                    System.exit(0);

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    	
        }catch (ClassNotFoundException e) {
			e.printStackTrace();
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
    }
}